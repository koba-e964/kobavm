package koba_app.compiler;

import java.io.*;
import java.util.*;
import static koba_app.compiler.Consts.*;
public class Rcr2rrc
{
	public static void main(String[] s)
	{
		try
		{
			new Rcr2rrc();
		}
		catch(Exception x)
		{
			x.printStackTrace();
		}
	}
	private static int getType(String s)
	{
		return new Token(s).getType();
	}
	public Rcr2rrc()throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String cmd=br.readLine();
		Token[] res=Token.split(cmd);
		trans(res,new Judger());
		for(int k=0;k<res.length;k++)
		{
			System.out.println(res[k]);
		}
		
	}
	public Tree trans(Token[] s,Judger jd)throws Exception
	{
		List<Token> t=new ArrayList<Token>(0x20);
		{
			for(Token tok : s)
				t.add(tok);
		}
		List<Tree> serve=new ArrayList<Tree>(0x30);

		{
			int beg=0;
			int end=0;
			int cur_type=-1;
			for(;end<t.size();)
			{
				Token tok=t.get(end);
				end++;
				//<KFLAT>
				/*
				{
					if(tok.toString().equals("oper"))
					{
						Token next=t.get(end);end++;
						if(new Judger().judge(next.toString())==TYPE||next.getType()==OPER)
						{}
						else
							throw new Exception("Compile Error!");
					}
					if(tok.toString().equals("new"))
					{
						Token next=t.get(end);end++;
						if(new Judger().judge(next.toString())==TYPE)
						{}
						else
							throw new Exception("Compile Error!");
					}
				}*/
				//</KFLAT>
				if(end>=1)
				{
					serve.add(new Tree(t.subList(beg,end).toArray(new Token[0]),(Tree[])null));
					beg=end;
				}
			}
		}
		//return null; // Test
		return Analyzer.compile(serve,jd);
		//throw new RuntimeException("auto String[] Rcr2rrc.trans(String)");
	}
}
