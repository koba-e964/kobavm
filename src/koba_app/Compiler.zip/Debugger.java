package koba_app.compiler;

public class Debugger extends Object
{
	public static void main(String[] args)throws Exception
	{
		new Rcr2rrc();
		System.out.println(new Judger());
	}
}