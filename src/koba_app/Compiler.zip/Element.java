package koba_app.compiler;
import static koba_app.compiler.Consts.*;
public interface Element
{}