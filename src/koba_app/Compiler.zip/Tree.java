package koba_app.compiler;
import static koba_app.compiler.Consts.*;
public class Tree implements Cloneable
{
	private Token[] val;
	private Tree[] children;

	public Tag tag=new Tag();
	public static class Tag
	{
		public int isOp=-1;//0:not-op,1:unary,2:binary
		public int prio=-1;//Priority
		public void setPrio(Token biop)
		{
			String op=biop.getToken();
			prio=calcPrio(op);
			return;
		}
		private int calcPrio(String op)
		{
			if(op.equals("*")||op.equals("/")||op.equals("%"))return 13;
			if(op.equals("+")||op.equals("-"))return 12;
			if(op.equals(">>")||op.equals("<<"))return 11;
			if(op.equals("==")||op.equals("!="))return 9;
			if(op.equals("&"))return 8;
			if(op.equals("^"))return 7;
			if(op.equals("|"))return 6;
			if(op.equals("&&"))return 5;
			if(op.equals("||"))return 4;
			if(op.equals("="))return 3;
			return 0;//Not a biop.
		}
	}


	public Tree(String s,Tree[] c)
	{
		this(s==null?(Token[])null:Token.split(s),c);
	}
	public Tree(Token[] toks,Tree[] c)
	{
		if(toks==null)
		{
			throw new NullPointerException("Tree.ctor(Token[],Tree[])");
		}
		val=new Token[toks.length];
		System.arraycopy(toks,0,val,0,toks.length);
		if(c!=null)
		{
			children=new Tree[c.length];
			System.arraycopy(c,0,children,0,c.length);
		}
	}
	public boolean canOperate(Judger j)
	{
		if
		(
			(
				(val.length==1&&val[0].getType()==OPER)||
				isCaster(j)
			)&&
			children==null
		)
			return true;
		return false;
	}





	public int getType(Judger j)
	{
		if(!canOperate(j))
			return VAR;
		if(val.length==1)
			return val[0].getIdentType(j);
		if(val.length==2)
			return isMethod(j)?METHOD:INVALID;
		if(val.length==3)
			return isCaster(j)?OPER:INVALID;
		throw new InternalError("Tree.getType(Judger)");
		
	}
	public boolean isValue(Judger j)//if it is value,or operator with arguments.
	{
		return children!=null||val.length==1&&val[0].isVar(j);
	}
	public boolean isOperator(Judger j)
	{
		return (val.length==1&&val[0].isOperator())||
			(val.length==3&&val[1].isType(j));
	}
	public boolean isMethod(Judger j)
	{
		return (val.length==1&&val[0].isMethod(j))||
				(val.length==2&&val[0].toString().equals("operator")&&val[1].isOperator());
	}
	public boolean isCaster(Judger j)
	{
		if(j==null)
			return new Judger().isType(Token.toString(val));
		if(val.length!=3)
			return false;
		return j.isType(val[1].toString());// "(" , typename , ")"
	}





	public Tree clone()throws CloneNotSupportedException
	{
		Tree t=(Tree)super.clone();
		t.val=val.clone();
		t.children=children.clone();
		return t;
	}
	public Token[] getTokens()
	{
		return val.clone();
	}
	public String toString()
	{
		String res="Vals:";
		if(val!=null)
		{
			for(Token t:val)
				if(t!=null)
					res+="\""+t+"\",";
				else
					res+="(Token)null";
		}
		if(children!=null)
		{
			res+="(";
			for(Tree e : children)
				if(e!=null)
					res+="\""+e+"\",";
				else
					res+="(Tree)null";
			res+=")";
		}
		return res;
	} 
}

