package koba_app.compiler;
import java.io.*;
import java.util.*;
public class Analyzer
{
	public static Tree compile(List<Tree> list,Judger jd)throws Exception
	{
		//For Debug
		{
			for(Tree tmp : list)
				System.out.println(tmp);
		}
		List<Tree> tr=new ArrayList<Tree>(list);
		int[] kakkos=getNextKakko(tr,0);
		if(kakkos!=null)
		{
			while(true)
			{
				int pos=0;
				List<Tree> arg=tr.subList(kakkos[0]+1,kakkos[1]);
				Tree res=compile(arg,jd);
				for(int k=kakkos[0];k<kakkos[1];k++)
				{
					tr.remove(kakkos[0]);//shift
				}
				tr.add(kakkos[0],res);
				pos=kakkos[0];

				kakkos=getNextKakko(tr,pos);
				if(kakkos==null)
					break;
			}
		}
		else
		{
				/*
				���̕������A�\����̗͂v�ƂȂ�B
				*/
			final int WHITE=1,UNOP=2,BIOP=3,VAL=4;
			int phase=-1;
			int pos=0;
			loop1:
			while(true)
			{
				sw0:
				switch(phase)
				{
				case WHITE:
					/*
						�ŏ��ɓ��������̂�VAL:����BIOP or "++/--" or nothing
						UNOP:����UNOP or VAL
						
					*/
					if(tr.get(pos).canOperate(jd))
					{
						tr.get(pos).tag.isOp=1;
						phase=UNOP;//"+","-"�Ȃǂ́Aunop,biop�̂ǂ���Ƃ��Ƃ�镨�́A�ŏ�biop�Ƃ����āA������unop�ɕϊ�����B
						pos++;
						break sw0;
					}
					else
					{
						
						phase=0;
					}
				case BIOP:
					
				case UNOP:
					
				case VAL:
				default:
					pos++;
				}
				if(pos>=tr.size())
					break;
			}
		}
		return null;
	}
	private static int[] getNextKakko(List<Tree> vs,int starts)//Returns "(",")"'s indexes
	{
		{
			System.out.print("getNextKakko(List,int)");
			for(Tree tmp : vs)
				System.out.println(tmp);
			System.out.println("starts="+starts);
		}
		int end=starts;
		while(end<vs.size()&&vs.get(end)!=null&&!vs.get(end).getTokens()[0].toString().equals(")"))
		{
			end++;
		}
		if(end>=vs.size())
		{
			return (int[])null;
		}
		int pos=end;
		while(pos>starts&&vs.get(pos)!=null&&!vs.get(pos).getTokens()[0].toString().equals("("))
		{
			pos--;
		}
		return new int[]{pos,end};
	}
	private static int getNext(List<Tree> vs,Judger jd,int starts,int type)
	{
		if(vs==null)
			return -1;
		int end=starts;
		while(end<vs.size())
		{
			if(vs.get(end).getType(jd)==type)
				return end;
			end++;
		}
		return -1;
	}
}