package koba_app.compiler;

import java.util.*;
import static koba_app.compiler.Consts.*;
public class Token
{
	public Token(Object obj)
	{
		this(String.valueOf(obj));
	}
	public Token(String s)
	{
		if(s.equals(""))
		{
			tok="";
			return;
		}
		if(!valid(s))
			throw new IllegalArgumentException();
		tok=s;
	}
	private static boolean valid(String s)
	{
		if(s.equals(""))
			return false;
		int initType=getType(s.charAt(0));
		if(initType==IDENT)
		{
			if(isNum(s.charAt(0)))
				if(!isNumLiteral(s))
					return false;
				else
					return true;
		}
		for(int k=1,len=s.length();k<len;k++)
		{
			if(initType!=getType(s.charAt(k)))
				return false;
		}
		return true;
	}
	public String getToken()
	{
		return tok;
	}
	public String toString()
	{
		return tok;
	}
	public static String toString(Token[] ts)
	{
		String res="";
		for(Token tk : ts)
			res+=tk;
		return res;
	}
	public Token clone()throws CloneNotSupportedException
	{
		Token t=(Token)super.clone();
		t.tok=tok;
		return t;
	}
	public int getType()
	{
		if(tok.length()==0)
			return 0;
		return getType(tok.charAt(0));
	}
	public boolean isOperator()
	{
		return getType()==OPER;
	}
	public int getIdentType(Judger j)
	{
		return j.judge(this.tok);
	}
	public boolean isVar(Judger j)
	{
		return j.isVar(this.tok);
	}
	public boolean isType(Judger j)
	{
		return j.isType(tok);
	}
	public boolean isMethod(Judger j)
	{
		return j.isMethod(tok);
	}
	private static boolean isNumLiteral(String s)
	{
		System.out.println("Token.isNumLiteral(String) is deprecated.");
		return isNum(s.charAt(0));
	}
	private static boolean isSpace(char a)
	{
		return a>=0&&a<=0x20;
	}
	private static boolean isAlp(char a)
	{
		return (a>='A'&&a<='Z')||(a>='a'&&a<='z');
	}
	private static boolean isNum(char a)
	{
		return a>='0'&&a<='9';
	}
	private static boolean isIdent(char a)
	{
		return isAlp(a)||isNum(a);
	}
	private static boolean isAscii(char a)
	{
		return a>=0&&a<0x80;
	}
	private static boolean isOperator(char a)
	{
		switch(a)
		{
			case '%':
			case '+':
			case '-':
			case '*':
			case '/':
			case '<':
			case '>':
			case '=':
			case '|':
			case '&':
			case '!':
			case '.':
				return true;
			default:
		}
		return false;
	}
	private static boolean isGram(char a)
	{
		switch(a)
		{
			case'[':
			case']':
			case'(':
			case')':
			case':':
				return true;
			default:
		}
		return false;
	}
	private static int getType(char a)
	{
		if(isIdent(a))		return IDENT;
		if(isOperator(a))	return OPER;
		if(isGram(a))		return GRAM;
		if(isSpace(a))		return SPACE;
					return 0;
	}
	private String tok;
	public static Token[] split(String s)
	{
		List<StringBuilder> out=new ArrayList<StringBuilder>(0x100);
		{
			int cLen=s.length();
			int curType=0;
			StringBuilder sb=new StringBuilder(0x100);
			for(int i=0;i<cLen;i++)
			{
				int tmp=getType(s.charAt(i));
				if(tmp==GRAM||curType!=tmp||
					(tmp==OPER&&s.charAt(i-1)!=s.charAt(i)))
				{
					out.add(sb);
					sb=new StringBuilder(0x100);
					curType=tmp;
				}
				sb.append(s.charAt(i));	
			}
			out.add(sb);
		}
		int chopFirst=out.get(0).toString().equals("")?1:0;
		Token[] res;
		{
			res=new Token[out.size()-chopFirst];
			for(int k=chopFirst,l=out.size();k<l;k++)
			{
				res[k-chopFirst]=new Token(out.get(k));
			}
		}
		List<Token> t=new ArrayList<Token>(0x20);
		{
			for(Token tmp : res)
			{
				if(tmp.getType()!=SPACE)
					t.add(tmp);
			}
		}
		return t.toArray(new Token[0]);
	}
}