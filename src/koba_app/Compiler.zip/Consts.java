package koba_app.compiler;
public interface Consts
{
	/**
		The kinds of words.
	*/
	public static int
			IDENT=1,
			OPER=2,
			GRAM=3,
			SPACE=4;
	/**
		The kinds of identifiers.
	*/
	public static int 
			TYPE=1,
			METHOD=2,
			VAR=3;
	/**
		Invalid value.
	*/
	public static int INVALID=-1;
}